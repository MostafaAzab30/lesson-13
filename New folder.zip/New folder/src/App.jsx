import logo from './logo.svg';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle";
import "font-awesome/css/font-awesome.min.css";
import './App.css';
import { render } from '@testing-library/react';



export default function App() {

   
function hello() {
    anotherpage.style.display = "none"
    pagetow.style.display = "none"
    pageyhree.style.display = "none"
    pagefour.style.display = "none"
    pagefifth.style.display = "none"
    pagesex.style.display = "none"
}

function imhere() {
    anotherpage.style.display = "flex"
}

function page2() {
    pagetow.style.display = "flex"
}

function page3() {
    pageyhree.style.display = "flex"
}

function page4() {
    pagefour.style.display = "flex"
}

function page5() {
    pagefifth.style.display = "flex"
}

function page6() {
    pagesex.style.display = "flex"
}












return (
<>



<header>

<nav id='nomps' class="navbar navbar-expand-lg bg-dark">
<div class="container">
<a class="navbar-brand fw-bold fs-2 text-white" href="#azab">Mostafa Azab</a>
<button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse mx-auto text-center" id="navbarSupportedContent">
<ul class="navbar-nav ms-auto ">
<li class="nav-item px-2 py-3">
<a class="nav-link fs-5 text-white fw-bold hove" aria-current="page" href="#Portfolio">Portfolio</a>
</li>
<li class="nav-item px-2 py-3">
<a class="nav-link fs-5 text-white fw-bold hove" href="#About">About</a>
</li>
<li class="nav-item px-2 py-3">
<a class="nav-link fs-5 text-white fw-bold hove" href="#Contact">Contact</a>
</li>



</ul>

</div>
</div>
</nav>


</header>





<section id='azab' className='happy '>

<div className=' w-50 mx-auto'>
<img src={require('./img/happy.png')} className="w-50 rounded-circle bg-info"/>

<h2 className='text-white big'>Azab React</h2>

<div className='d-flex help'>

<div className='mos w-25 bg-white rounded'></div>
<div className='fs-1 text-white mx-3'>✮</div>
<div className='mos w-25 bg-white rounded'></div>

</div>

<h4 className='text-white'>Graphic Designer - Web Designer - Illustrator</h4>




</div>
</section>





<section id='Portfolio' className='diff text-center my-5'>

<h2 className='next'>Portfolio</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>


<div className='container'>
<div className='row mt-4'>

<div className='col-4 mb-4'>
<div onClick={imhere} className='house'>
<img src={require("./img/1.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>

<div className='col-4 mb-4'>
<div onClick={page2} className='house'>
<img  src={require("./img/2.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>

<div className='col-4 mb-4'>
<div onClick={page3} className='house'>
<img src={require("./img/3.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>

<div className='col-4 mb-4'>
<div onClick={page4} className='house'>
<img src={require("./img/4.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>

<div className='col-4 mb-4'>
<div onClick={page5} className='house'>
<img src={require("./img/5.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>

<div className='col-4 mb-4'>
<div onClick={page6} className='house'>
<img src={require("./img/6.png")} className='w-100 rounded mero' />
<h5 className='fw-bold'>Click Here</h5>
</div>
</div>







</div>


</div>






</section>






<section id='About' className='holy'>


<div className='w-75 '>
<h2 className='text-center next'>About</h2>

<div className='d-flex help'>

<div className='mos zoz bg-white rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-white rounded'></div>

</div>

<div className='d-flex'>

<p className='spac'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam repudiandae deserunt nam ad adipisci nisi excepturi ratione, labore reiciendis, aspernatur unde repellendus esse officiis. Suscipit nobis doloribus unde nihil aspernatur.</p>

<p className='spac'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Inventore quis alias velit minima similique! Consequatur dolores consequuntur excepturi hic, fugit dolorem perspiciatis dignissimos rem asperiores voluptatibus dolorum necessitatibus, amet non?</p>

</div>







</div>

</section>







<section id='Contact' className='w-75 mx-auto text-center my-5'>

<h2 className='next'>Contact Me</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>


<input type="text" className='hiden' placeholder='Name' />
<hr />

<input type="email" className='hiden' placeholder='Email' />
<hr />

<input type="number" className='hiden' placeholder='Phone Number'/>
<hr />

<textarea cols="30" rows="6" className='hiden' placeholder='Message'></textarea>
<hr />
<button className='btn btn-dark p-3 d-block'>Send</button>





</section>







<footer className='footer'>

<div className='container text-white text-center'>
<div className='row'>

<div className='col-4 my-5 '>

<h3 className='fw-bold'>Location</h3>
<h5>2215 John Danel Drive Clark,MO 65243</h5>


</div>

<div className='col-4 my-5'>

<h3 className='fw-bold mb-4'>About The Web</h3>


<span className='icon-facebook dad rounded-circle text-white'>
</span>
<span className='icon-twitter dad rounded-circle text-white'>
</span>
<span className='icon-instagram dad rounded-circle text-white'>
</span>
<span className='icon-envelop dad rounded-circle text-white'>
</span>


</div>

<div className='col-4 my-5'>

<h3 className='fw-bold'>About FreeLancer</h3>
<h5>Freelance is a free to use, MIT licensed Bootstrap theme created by Route</h5>


</div>




</div>
</div>
</footer>





<h6 className='bg-dark text-white text-center py-4 my-0 '>Copyright © Your Website 2021</h6>






<section id='anotherpage' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>Log Cabin</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/1.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>



<section id='pagetow' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>TASTY CAKE</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-2'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/2.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>



<section id='pageyhree' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>CIRCUS TENT</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/3.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>



<section id='pagefour' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>CONTROLLER</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/4.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>



<section id='pagefifth' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>LOCKED SAFE</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/5.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>



<section id='pagesex' onClickCapture={hello} className='hidepage '>

<div className=' sonhide rounded text-center mx-auto'>

<h2 className='next'>SUBMARINE</h2>


<div className='d-flex help'>

<div className='mos zoz bg-danger rounded'></div>
<div className='fs-1 mx-3'>✮</div>
<div className='mos zoz bg-danger rounded'></div>

</div>
<br />
<img src={require("./img/6.png")} className='w-50 rounded mx-auto' />

<br />
<br />
<br />
<p className='w-50 mx-auto'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis quasi asperiores dignissimos repudiandae itaque? Numquam iure aperiam facere? Maiores ea ipsa qui doloremque veritatis corrupti earum? Omnis, nostrum. Asperiores, debitis?</p>
<br />
<button onClick={hello} className='btn btn-dark '><span className='icon-plus pe-2'></span>Close Window</button>

<span className='icon-plus loly' onClick={hello}></span>


</div>





</section>


</>

)}


